import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class Server extends JFrame {
	
	private ImageIcon img = new ImageIcon("C:\\Users\\Marcelo\\eclipse-workspace\\Instant Messenger\\res\\serverIcon.png");
	private JTextField userText;
	private JTextPane chatWindow;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private ServerSocket server;
	private Socket connection;
	final private int defaultPort = 41998;
	private int port;
	final private int defaultBackLog = 10;
	private int backLog;
	static private ServerState serverInfo = new ServerState();
	private String serverName = "";
	

		
	
	//constructor
	/**
	 * Creates a server object on the IP of the computer, which will wait for a client connection on the default port of 0000 with a default backlog of 10.
	 */
	public Server() {
		super("Instant Messaging Server");
		port = defaultPort;
		backLog = defaultBackLog;
		setTitle("Instant Messaging Server");
		setIconImage(img.getImage());
		userText = new JTextField();
		userText.setFont(new Font("Tahoma", Font.PLAIN, 12));
		userText.setEditable(false);
		userText.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						sendMessage(event.getActionCommand());
						userText.setText("");
					}
				}
			);
		getContentPane().add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextPane();
		chatWindow.setFont(new Font("Tahoma", Font.PLAIN, 12));
		//panel.add(chatWindow);
		//panel.add(new JScrollPane(chatWindow));
		getContentPane().add(new JScrollPane(chatWindow), BorderLayout.CENTER);
		setSize(600,300);
		setResizable(false);
		setVisible(true);
		//W.I.P.
		try {
			serverInfo.readFromFile("name.data");
			System.out.println(serverInfo.getName());
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Creates a server object on the IP of the computer, which will wait for a client connection on the set port with a set backlog.
	 * @param port the port of the server
	 * @param backLog the backlog amount
	 */
	public Server(int port, int backLog) {
		super("Instant Messaging Server");
		this.port = port;
		this.backLog = backLog;
		setTitle("Instant Messaging Server");
		setIconImage(img.getImage());
		userText = new JTextField();
		userText.setFont(new Font("Tahoma", Font.PLAIN, 12));
		userText.setEditable(false);
		userText.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						sendMessage(event.getActionCommand());
						userText.setText("");
					}
				}
			);
		getContentPane().add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextPane();
		chatWindow.setFont(new Font("Tahoma", Font.PLAIN, 12));
		//panel.add(chatWindow);
		//panel.add(new JScrollPane(chatWindow));
		getContentPane().add(new JScrollPane(chatWindow), BorderLayout.CENTER);
		setSize(600,300);
		setResizable(false);
		setVisible(true);
		//W.I.P.
		try {
			serverInfo.readFromFile("name.data");
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Set up and Run the server.
	 */
	public void startRunning() {
		try {
			serverInfo.readFromFile("name.data");
			System.out.println(serverInfo.getName());
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			server = new ServerSocket(port, backLog);
			while(true) {
				try {
					showMessage("The address of this computer is: ", Color.BLUE);
					showMessage(InetAddress.getLocalHost().getHostAddress().toString() + ":" + port + "\n", Color.magenta);
					showMessage("NOTE:\nIf the IP adress is NOT public, it will be impossible to connect from outside the network!\n", Color.BLUE);
					//connect and converse
					waitForConnection();
					setupStreams();
					whileChatting();
				}catch(EOFException eofException) {
					showMessage("ERROR: EOFEXCEPTION, END OF STREAM HAS BEEN REACHED UNEXPECTEDLY\n" , Color.RED);
					eofException.printStackTrace();
					//showMessage("\n Server ended the connection!");
				}catch(SocketTimeoutException socketTimeoutException) {
					showMessage("ERROR: SOCKETTIMEOUTEXCEPTION, TOOK TO LONG TO RECEIVE RESPONSE\n" + socketTimeoutException.toString() + "\n", Color.RED);
					socketTimeoutException.printStackTrace();
				}catch(SocketException socketException) {
					showMessage("ERROR: SOCKETEXCEPTION, CONNECTION RESET ABRUPTEDLY OR BY CLIENT\n" + socketException.toString() + "\n", Color.RED);
					socketException.printStackTrace();
				}catch(Exception e) {
					showMessage("\n ERROR: UNKOWN EXCEPTION TERMINATED CONNECTION \n" + e.toString() +"\n", Color.RED);
					e.printStackTrace();
				}finally {
					closeAll();
					//W.I.P.
					try {
						serverInfo.writeToFile("name.data");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}catch(BindException bindException) {
			showMessage("ERROR: BINDEXCEPTION, ADRESS ALREADY IN USE OR THE LISTEN BACKLOG QUEUE IS FULL\n" + bindException.toString() + "\n" + "CLOSE THIS AND OTHER APPLICATIONS RUNNING ON THE SAME PORT: " + port, Color.RED);
			bindException.printStackTrace();
//		}catch(ConnectException connectException) {
//			showMessage("ERROR: NO SERVICE LISTENING ON ", Color.RED);
//			showMessage(serverIP + "\n", Color.MAGENTA);
//			showMessage(connectException.toString() + "\n", Color.RED);
		}catch(IOException ioException) {
			showMessage("ERROR: IOEXCEPTION, UNKNOWN IOEXCEPTION\n" + ioException.toString() +"\n", Color.RED);
			ioException.printStackTrace();
		}
	}
	
	
	
	
	
	/**
	 * Wait for connection, then once connected displays connection information.
	 */
	private void waitForConnection() throws IOException {
		ableToType(false);
		showMessage("Waiting for someone to connect. . . \n", Color.BLUE);
		connection = server.accept();
		showMessage(" Connection Established with ", Color.BLUE);
		showMessage(connection.getInetAddress().getHostName() + ":" + port + "\n", Color.GREEN);
	}
	
	/**
	 * Setup streams to send and receive data.
	 */
	private void setupStreams() throws IOException {
		output = new ObjectOutputStream(connection.getOutputStream());
		output.flush();
		input = new ObjectInputStream(connection.getInputStream());
		showMessage(" Streams are now setup!\n\n", Color.BLUE);
		//showMessage("\n Streams are now setup!\n");
	}
	/**
	 * 
	 * @throws IOException
	 */
	private void whileChatting() throws IOException {
		String message;
//		if (serverInfo.getName().equals("")) {
		if (serverName.equals("")) {
			message = "***You are now connected***";
		}
		else {
			message = "***You are now connected to " + serverName + "***";
		}
		sendMessage(message);
		ableToType(true);
		do {
			try {
				message = (String) input.readObject();
				if (message.indexOf("/") == 0){
					showMessage(" [CLIENT:"+ connection.getInetAddress().getHostAddress() + "] " + message + "\n", Color.GRAY);
				}
				else {
					showMessage(" [CLIENT:"+ connection.getInetAddress().getHostAddress() + "] ", Color.GREEN);
					showMessage(message + "\n", Color.BLUE);
				}
			}catch(ClassNotFoundException classNotFoundException) {
				showMessage(" ERROR: CLASSNOTFOUNDEXCEPTION, USER SENT UNREADABLE INFORMATION!\n" + classNotFoundException.toString() + "\n", Color.RED);
				classNotFoundException.toString();
			}
		}while(!message.equals("/end"));
		showMessage("CLIENT terminated the connection!\n", Color.GREEN);
	}
	/**
	 * Closes sockets and ends streams when called.
	 */
	private void closeAll() {
		//showMessage("\n Closing connections. . . \n");
		showMessage("Closing connections. . . \n\n\n", Color.ORANGE);
		ableToType(false);
		try {
			output.close();
			input.close();
			connection.close();
		}catch(NullPointerException nullPointerException) {
			showMessage("ERROR: NULLPOINTEREXCEPTION, NO STREAMS TO CLOSE\n", Color.RED);
			showMessage(nullPointerException.toString() + "\n", Color.RED);
			nullPointerException.printStackTrace();
		}catch(IOException ioException) {
//			showMessage("ERROR: ");
//			showMessage(ioException.toString(), Color.RED);
			ioException.printStackTrace();
		}catch(Exception e) {
			showMessage("\nERROR: UNKNOWN EXCEPTION DURING CLOSEALL \n", Color.RED);
			showMessage(e.toString() + "\n", Color.RED);
			e.printStackTrace();
		}finally {
			showMessage("Connections closed successfully!\n", Color.GREEN);
		}
	}
	/**
	 * Sends a message through the output stream, flushes any leftover information afterwards.
	 * @param message the message to be sent
	 */
	private void sendMessage(String message) {
		try {
			if(!message.equals("") && !message.startsWith("/")) {
				output.writeObject(message);
				output.flush();
				showMessage(" [SERVER] ", Color.MAGENTA);
				showMessage(message + "\n", Color.BLUE);
			}
			else if(message.indexOf("/help") == 0) {
				showMessage(" [SERVER] " + message + "\n", Color.GRAY);
				showMessage(" COMMAND LIST:\n /log : saves a copy of the conversation to the res folder\n /setName : sets the serverName\n /end : terminates the connection with the client\n", Color.DARK_GRAY);
				
			}
			else if(message.indexOf("/log") == 0) {
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/d k:m:s a");
				showMessage(" [SERVER] " + message + "\n", Color.GRAY);
				showMessage(" UPLOADED TO log.txt at" + sdf.format(cal.getTime()) + "\n");
			}
			else if(message.indexOf("/end") == 0) {
				output.writeObject(message);
				output.flush();
				showMessage(" [SERVER] " + message + "\n", Color.GRAY);
			}
			else if(message.indexOf("/setName") == 0) {
//				setServerName(message.substring(9, message.length()));
//				showMessage(" [SERVER] ", Color.MAGENTA); showMessage("renamed serverName to: " + serverInfo.getName() + "\n", Color.BLUE);
//				output.writeObject(" renamed serverName to: " + serverInfo.getName());
//				output.flush();
				setServerName(message.substring(9, message.length()));
				showMessage(" [SERVER] ", Color.MAGENTA); showMessage("renamed serverName to: " + serverName + "\n", Color.BLUE);
				output.writeObject("renamed serverName to: " + serverName);
				output.flush();
			}
//			else {
//				showMessage(" [SERVER] " + message + " Is not a valid command!\n", Color.GRAY);
//			} 
		}catch(IOException ioException) {
			showMessage(" ERROR: IOEXCEPTION, MESSAGE NOT SENDABLE!\n" + ioException.toString() + "\n", Color.RED);
			ioException.toString();
			//chatWindow.append("\n ERROR - MESSAGE NOT SENDABLE!");
		}
	}
	/**
	 * Updates the chatWindow with @param text 
	 * @param text the text to update the window with
	 */
	private void showMessage(final String text) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					appendToPane(chatWindow, text, Color.BLACK);
					//chatWindow.append(text);
				}
			}
		);
		
	}
	
	void setServerName(String serverName) {
//		serverInfo.setName(serverName);
		this.serverName = serverName;
	}
	
	private void showMessage(final String text, Color c) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					appendToPane(chatWindow, text, c);
					//chatWindow.append(text);
				}
			}
		);
		
	}
	
//	private void showMessage(final String text, Style s) {
//		SwingUtilities.invokeLater(
//			new Runnable() {
//				public void run() {
//					appendToPane(chatWindow, text, Color.BLACK);
//					//chatWindow.append(text);
//				}
//			}
//		);
//		
//	}
	/**
	 * Allows the user to type text in the chat box.
	 * @param canType boolean entered to give/take access to the text box.
	 */
	private void ableToType(final boolean canType) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					userText.setEditable(canType);
				}
			}
		);
	}
	
	private void appendToPane(JTextPane tp, String msg, Color c) {
		StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
	}
}
