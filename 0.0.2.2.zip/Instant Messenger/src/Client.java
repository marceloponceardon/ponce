import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class Client extends JFrame {
	
//	private ImageIcon img = new ImageIcon("C:\\Users\\Marcelo\\eclipse-workspace\\Instant Messenger\\res\\serverIcon.png");
	private JTextField userText;
	private JTextPane chatWindow;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private String message = "";
	private String serverIP;
	private Socket connection;
	final private int defaultPort = 41998;
	private int port;
	final private String defaultName = "user";
	private String nickName = defaultName;
	/**
	 * Creates a client object which will attempt connection with the server on the default port of 0000.
	 * @param host the IP address of the server
	 */
	public Client(String host) {
		super("Instant Messaging Client");
		port = defaultPort;
		setTitle("Instant Messaging Client");
		serverIP = host;
		userText = new JTextField();
		userText.setFont(new Font("Tahoma", Font.PLAIN, 12));
		userText.setEditable(false);
		userText.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					sendMessage(event.getActionCommand());
					userText.setText("");
				}
			}
		);
		getContentPane().add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextPane();
		chatWindow.setFont(new Font("Tahoma", Font.PLAIN, 12));
		getContentPane().add(new JScrollPane(chatWindow), BorderLayout.CENTER);
		setSize(600,300);
		setResizable(false);
		setVisible(true);
	}
	/**
	 * Creates a client object which will attempt connection with the server on the set port.
	 * @param host the IP address of the server
	 * @param port the port of the server
	 */
	public Client(String host, int port) {
		super("Instant Messaging Client");
		this.port = port;
		setTitle("Instant Messaging Client");
		serverIP = host;
		userText = new JTextField();
		userText.setFont(new Font("Tahoma", Font.PLAIN, 12));
		userText.setEditable(false);
		userText.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					sendMessage(event.getActionCommand());
					userText.setText("");
				}
			}
		);
		getContentPane().add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextPane();
		chatWindow.setFont(new Font("Tahoma", Font.PLAIN, 12));
		getContentPane().add(new JScrollPane(chatWindow), BorderLayout.CENTER);
		setSize(600,300);
		setResizable(false);
		setVisible(true);
	}
	
	
	//connect to server
	public void startRunning() {
		try {
			
			connectToServer();
			setupStreams();
			whileChatting();
		}catch(EOFException eofException) {
			//showMessage("\n Client terminated connection.");
			showMessage("ERROR: EOFEXCEPTION, END OF STREAM HAS BEEN REACHED UNEXPECTEDLY\n", Color.RED);
			eofException.printStackTrace();
		}catch(ConnectException connectException) {
			showMessage("ERROR: CONNECTEXCEPTION, NO SERVICE LISTENING ON: " + serverIP + ":"+ port + " OR PORT IS INVALID\n" + connectException.toString() + "\n", Color.RED);
			connectException.printStackTrace();
		}catch(SocketException socketException) {
			showMessage("ERROR: SOCKETEXCEPTION, CONNECTION RESET ABRUPTEDLY OR BY SERVER\n" + socketException.toString() + "\n", Color.RED);
			socketException.printStackTrace();
		}catch(SocketTimeoutException socketTimeoutException) {
			showMessage("ERROR: SOCKETTIMEOUTEXCEPTION, TOOK TO LONG TO RECEIVE RESPONSE\n" + socketTimeoutException.toString() + "\n", Color.RED);
			socketTimeoutException.printStackTrace();
		}catch(IOException ioException) {
			showMessage("ERROR: IOEXCEPTION, UNKNOWN IOEXCEPTION\n" + ioException.toString() + "\n", Color.RED);
			ioException.printStackTrace();
		}catch(Exception e) {
			showMessage("\nERROR: UNKOWN EXCEPTION TERMINATED CONNECTION\n" + e.toString() +"\n", Color.RED);
			e.printStackTrace();
		}finally {
			closeAll();
			showMessage("Client terminated successfully!\n", Color.GREEN);
		}
		
	}
	/**
	 * Tries to connect to the address, once connected displays connection information.
	 * @throws IOException
	 */
	
	private void connectToServer() throws IOException {
		//showMessage("Attempting connection. . . \n");
		showMessage("Attempting connection with ", Color.BLUE);
		showMessage(serverIP + ":" + port, Color.MAGENTA);
		showMessage(" . . .\n", Color.BLUE);
		connection = new Socket(InetAddress.getByName(serverIP), port);
		//showMessage("Connection established with: " + connection.getInetAddress().getHostName());
		showMessage(" Connection Established with ", Color.BLUE);
		showMessage(connection.getInetAddress().getHostName() + ":" + port + "\n", Color.MAGENTA);
	}
	/**
	 * Setup streams to send and receive data.
	 * @throws IOException
	 */
	private void setupStreams() throws IOException {
		output = new ObjectOutputStream(connection.getOutputStream());
		output.flush();
		input = new ObjectInputStream(connection.getInputStream());
		//showMessage("\n Streams set up! \n");
		showMessage(" Streams are now setup!\n\n", Color.BLUE);
	}
	/**
	 * 
	 * @throws IOException
	 */
	private void whileChatting() throws IOException {
		ableToType(true);
		do {
			try {
				message = (String) input.readObject();
				//showMessage("\n SERVER: " + message);
				if (!message.equals("/end")) {
					showMessage(" [SERVER] ", Color.MAGENTA);
					showMessage(message + "\n", Color.BLUE);
				}
			}catch(ClassNotFoundException classNotFoundException) {
				//showMessage("\n User sent unreadable information!");
				showMessage("ERROR: CLASSNOTFOUNDEXCEPTION, USER SENT UNREADABLE INFORMATION!\n" + classNotFoundException.toString(), Color.RED);
				classNotFoundException.printStackTrace();
			}
		}while (!message.equals("/end"));
		showMessage("SERVER terminated the connection!\n", Color.MAGENTA);
	}
	
	private void closeAll() {
		//showMessage("\n Closing connections. . . ");
		showMessage("Closing connections. . . \n\n\n", Color.ORANGE);
		ableToType(false);
		try {
			output.close();
			input.close();
			connection.close();
		}catch(NullPointerException nullPointerException) {
			showMessage("ERROR: NULLPOINTEREXCEPTION, NO STREAMS TO CLOSE\n", Color.RED);
			showMessage(nullPointerException.toString() + "\n", Color.RED);
			nullPointerException.printStackTrace();
		}catch(IOException ioException) {
//			showMessage("ERROR: ");
//			showMessage(ioException.toString(), Color.RED);
			ioException.printStackTrace();
		}catch(Exception e) {
			showMessage("\nERROR: UNKNOWN EXCEPTION DURING CLOSEALL \n", Color.RED);
			showMessage(e.toString() + "\n", Color.RED);
			e.printStackTrace();
		}finally {
			showMessage("Connections closed successfully!\n", Color.GREEN);
		}
	}
	
	private void sendMessage(String message) {
		try {
			if(!message.equals("") && !message.startsWith("/")) {
				output.writeObject(message);
				output.flush();
				//showMessage("\nCLIENT: " + message);
				showMessage(" [CLIENT:" + nickName + "] ", Color.GREEN);
				showMessage(message + "\n", Color.BLUE);
			}
			else if(message.indexOf("/help") == 0) {
				output.writeObject(message);
				output.flush();
				showMessage(" [CLIENT:" + nickName + "] " + message + "\n", Color.GRAY);
				showMessage(" COMMAND LIST:\n /nick : set's the nickname\n /log : saves a copy of the conversation to the res folder\n /end : terminates the connection with the server\n", Color.DARK_GRAY);
			}
			else if(message.indexOf("/nick") == 0) {
				output.writeObject(message);
				output.flush();
				setNickName(message.substring(5, message.length()));
				showMessage(" [CLIENT:" + nickName + "] " + message + "\n", Color.GRAY);
			}
			else if(message.indexOf("/log") == 0) {
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/d k:m:s a");
				showMessage(" [CLIENT:" + nickName +"] " + message + "\n", Color.GRAY);
				showMessage(" UPLOADED TO log.txt at" + sdf.format(cal.getTime()) + "\n");
			}
			else if(message.indexOf("/end") == 0) {
				output.writeObject(message);
				output.flush();
				showMessage(" [CLIENT:" + nickName + "] " + message + "\n", Color.GRAY);
			}
//			else {
//				output.writeObject(message + " Is not a valid command!");
//				output.flush();
//				showMessage(" [CLIENT:" + nickName + "] " + message + " Is not a valid command!\n", Color.GRAY);
//			}
		}catch(IOException ioException) {
			showMessage("ERROR: IOEXCEPTION, MESSAGE NOT SENDABLE!\n", Color.RED);
			//chatWindow.append("\n Unable to send message!");
		}
	}
	
	private void setNickName(String nickName) {
		nickName = nickName.replaceAll("//s", "");
		if(!nickName.equals("")) {
			this.nickName = nickName.replaceAll(" ", "");
		}
		else {
			this.nickName = "user";
		}
	}
	
	private void showMessage(final String text) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					appendToPane(chatWindow, text, Color.BLACK);
					//chatWindow.append(message);
				}
			}
		);
	}
	
	private void showMessage(final String text, Color c) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					appendToPane(chatWindow, text, c);
					//chatWindow.append(message);
				}
			}
		);
	}
	
	private void ableToType(final boolean canType) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					userText.setText("");
					userText.setEditable(canType);
				}
			}
		);
	}
	
	private void appendToPane(JTextPane tp, String msg, Color c) {
		StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
	}
}
