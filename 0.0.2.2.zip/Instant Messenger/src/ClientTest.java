import java.io.IOException;

import javax.swing.JFrame;

public class ClientTest {
	public static void main(String[] args) {
		Client c = new Client("10.32.48.60", 34169);
		c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		c.startRunning();
	}
}
