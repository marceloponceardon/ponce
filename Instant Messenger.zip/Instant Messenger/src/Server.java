import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class Server extends JFrame {
	
	private ImageIcon img = new ImageIcon("C:\\Users\\Marcelo\\eclipse-workspace\\Instant Messenger\\res\\serverIcon.png");
	private JTextField userText;
	private JTextPane chatWindow;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private ServerSocket server;
	private Socket connection;
	final private int defaultPort = 41998;
	private int port;
	final private int defaultBackLog = 10;
	private int backLog;
	private String serverNickName = "";
	//constructor
	/**
	 * Creates a server object on the IP of the computer, which will wait for a client connection on the default port of 0000 with a default backlog of 10.
	 */
	public Server() {
		super("Instant Messaging Server");
		port = defaultPort;
		backLog = defaultBackLog;
		setTitle("Instant Messaging Server");
		setIconImage(img.getImage());
		userText = new JTextField();
		userText.setFont(new Font("Tahoma", Font.PLAIN, 12));
		userText.setEditable(false);
		userText.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						sendMessage(event.getActionCommand());
						userText.setText("");
					}
				}
			);
		getContentPane().add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextPane();
		chatWindow.setFont(new Font("Tahoma", Font.PLAIN, 12));
		//panel.add(chatWindow);
		//panel.add(new JScrollPane(chatWindow));
		getContentPane().add(new JScrollPane(chatWindow), BorderLayout.CENTER);
		setSize(600,300);
		setVisible(true);
		
	}
	/**
	 * Creates a server object on the IP of the computer, which will wait for a client connection on the set port with a set backlog.
	 * @param port the port of the server
	 * @param backLog the backlog amount
	 */
	public Server(int port, int backLog) {
		super("Instant Messaging Server");
		this.port = port;
		this.backLog = backLog;
		setTitle("Instant Messaging Server");
		setIconImage(img.getImage());
		userText = new JTextField();
		userText.setFont(new Font("Tahoma", Font.PLAIN, 12));
		userText.setEditable(false);
		userText.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						sendMessage(event.getActionCommand());
						userText.setText("");
					}
				}
			);
		getContentPane().add(userText, BorderLayout.SOUTH);
		chatWindow = new JTextPane();
		chatWindow.setFont(new Font("Tahoma", Font.PLAIN, 12));
		//panel.add(chatWindow);
		//panel.add(new JScrollPane(chatWindow));
		getContentPane().add(new JScrollPane(chatWindow), BorderLayout.CENTER);
		setSize(600,300);
		setVisible(true);
		
	}
	/**
	 * Set up and Run the server.
	 */
	public void startRunning() {
		try {
			server = new ServerSocket(port, backLog);
			while(true) {
				try {
					//connect and converse
					waitForConnection();
					setupStreams();
					whileChatting();
				}catch(EOFException eofException) {
					showMessage("SERVER terminated the connection!\n" , Color.MAGENTA);
					eofException.printStackTrace();
					//showMessage("\n Server ended the connection!");
				}catch(SocketException socketException) {
					showMessage("ERROR: SOCKETEXCEPTION, CONNECTION RESET ABRUPTEDLY OR BY CLIENT\n" + socketException.toString() + "\n", Color.RED);
					socketException.printStackTrace();
				}catch(Exception e) {
					showMessage("\nERROR: UNKOWN EXCEPTION TERMINATED CONNECTION \n" + e.toString() +"\n", Color.RED);
					e.printStackTrace();
				}finally {
					closeAll();
				}
			}
		}catch(BindException bindException) {
			showMessage("ERROR: ADRESS ALREADY IN USE\n" + bindException.toString() + "\n" + "CLOSE THIS AND OTHER APPLICATIONS RUNNING ON THE SAME PORT: " + port, Color.RED);
			bindException.printStackTrace();
//		}catch(ConnectException connectException) {
//			showMessage("ERROR: NO SERVICE LISTENING ON ", Color.RED);
//			showMessage(serverIP + "\n", Color.MAGENTA);
//			showMessage(connectException.toString() + "\n", Color.RED);
		}catch(IOException ioException) {
			showMessage("ERROR: IOEXCEPTION, UNKNOWN IOEXCEPTION\n" + ioException.toString() +"\n", Color.RED);
			ioException.printStackTrace();
		}
	}
	
	
	
	
	/**
	 * Wait for connection, then once connected displays connection information.
	 */
	private void waitForConnection() throws IOException {
		ableToType(false);
		showMessage("Waiting for someone to connect. . . \n", Color.BLUE);
		connection = server.accept();
		showMessage(" Connection Established with ", Color.BLUE);
		showMessage(connection.getInetAddress().getHostName() + ":" + port + "\n", Color.GREEN);
	}
	
	/**
	 * Setup streams to send and receive data.
	 */
	private void setupStreams() throws IOException {
		output = new ObjectOutputStream(connection.getOutputStream());
		output.flush();
		input = new ObjectInputStream(connection.getInputStream());
		showMessage(" Streams are now setup!\n\n", Color.BLUE);
		//showMessage("\n Streams are now setup!\n");
	}
	/**
	 * 
	 * @throws IOException
	 */
	private void whileChatting() throws IOException {
		String message = "***You are now connected***";
		sendMessage(message);
		ableToType(true);
		do {
			try {
				message = (String) input.readObject();
				//showMessage("\n" + message);
				showMessage(" CLIENT: ", Color.GREEN);
				showMessage(message + "\n", Color.BLUE);
			}catch(ClassNotFoundException classNotFoundException) {
				showMessage(" ERROR: CLASSNOTFOUNDEXCEPTION, USER SENT UNREADABLE INFORMATION!\n" + classNotFoundException.toString() + "\n", Color.RED);
				classNotFoundException.toString();
				//showMessage("\n User sent unreadable information!");
			}
		}while(!message.equals(".end"));
		showMessage("CLIENT terminated the connection!\n", Color.GREEN);
	}
	/**
	 * Closes sockets and ends streams when called.
	 */
	private void closeAll() {
		//showMessage("\n Closing connections. . . \n");
		showMessage("Closing connections. . . \n\n\n", Color.ORANGE);
		ableToType(false);
		try {
			output.close();
			input.close();
			connection.close();
		}catch(IOException ioException) {
			ioException.printStackTrace();
		}
	}
	/**
	 * Sends a message through the output stream, flushes any leftover information afterwards.
	 * @param message the message to be sent
	 */
	private void sendMessage(String message) {
		try {
			if(!message.equals("")) {
				output.writeObject(message);
				output.flush();
				showMessage(" SERVER: ", Color.MAGENTA);
				showMessage(message + "\n", Color.BLUE);
			}
		}catch(IOException ioException) {
			showMessage(" ERROR: IOEXCEPTION, MESSAGE NOT SENDABLE!\n" + ioException.toString() + "\n", Color.RED);
			ioException.toString();
			//chatWindow.append("\n ERROR - MESSAGE NOT SENDABLE!");
		}
	}
	/**
	 * Updates the chatWindow with @param text 
	 * @param text the text to update the window with
	 */
	private void showMessage(final String text) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					appendToPane(chatWindow, text, Color.BLACK);
					//chatWindow.append(text);
				}
			}
		);
		
	}
	
	private void showMessage(final String text, Color c) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					appendToPane(chatWindow, text, c);
					//chatWindow.append(text);
				}
			}
		);
		
	}
	
//	private void showMessage(final String text, Style s) {
//		SwingUtilities.invokeLater(
//			new Runnable() {
//				public void run() {
//					appendToPane(chatWindow, text, Color.BLACK);
//					//chatWindow.append(text);
//				}
//			}
//		);
//		
//	}
	/**
	 * Allows the user to type text in the chat box.
	 * @param canType boolean entered to give/take access to the text box.
	 */
	private void ableToType(final boolean canType) {
		SwingUtilities.invokeLater(
			new Runnable() {
				public void run() {
					userText.setEditable(canType);
				}
			}
		);
	}
	
	private void appendToPane(JTextPane tp, String msg, Color c) {
		StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
	}
}
