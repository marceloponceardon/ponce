import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ServerState implements Serializable {
	String name = "";
	String info = "";
	String user = "";
	String settings = "";
	
	String getName() {
		return name;
	}
	
	void setName(String name) {
		this.name = name;
	}
	
	String getInfo() {
		return info;
	}
	
	void setInfo(String info) {
		this.info = info;
	}
	
	String getUser() {
		return user;
	}
	
	void setUser(String user) {
		this.user = user;
	}
	
	String getSettings() {
		return settings;
	}
	
	void setSettings(String settings) {
		this.settings = settings;
	}
	
	void writeToFile(String fileName) throws IOException {
		    FileOutputStream fos = new FileOutputStream(fileName, true);
		    ObjectOutputStream oos = new ObjectOutputStream(fos);
		    try {
				oos.writeObject(getName());
//				oos.writeObject(info);
//				oos.writeObject(user);
//				oos.writeObject(settings);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    oos.close();
	}
	
	void readFromFile(String fileName) throws IOException, ClassNotFoundException {
		FileInputStream fis = new FileInputStream(fileName);
		ObjectInputStream ois = new ObjectInputStream(fis);
		try {
			setName((String) ois.readObject());
			System.out.println(name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		ois.close();
	}
}